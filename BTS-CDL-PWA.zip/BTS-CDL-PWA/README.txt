BTS CDL Study Guide PWA

This folder is a Progressive Web App. It must be hosted on an HTTPS website for installation and offline features to work reliably.

Files to upload together:
- index.html
- manifest.webmanifest
- service-worker.js
- icons folder

After hosting:
1. Open the website in Chrome on Android.
2. Tap the browser menu.
3. Tap "Add to Home screen" or "Install app."
4. The BTS icon will appear on the phone.

Cash App donation link: $W122074
